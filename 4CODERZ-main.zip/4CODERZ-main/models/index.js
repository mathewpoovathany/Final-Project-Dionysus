module.exports = {
  Pairing: require("./pairingsSchema.js")
};