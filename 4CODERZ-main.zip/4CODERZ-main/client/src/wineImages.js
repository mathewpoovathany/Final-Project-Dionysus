export default [
  {
    id: 0,
    image: require("./components/Images/wineImages/cakebread2.jpg")
  },
  {
    id: 1,
    image: require("./components/Images/wineImages/chateau2.jpg")
  },
  {
    id: 2,
    image: require("./components/Images/wineImages/domaine2.jpg")
  },
  {
    id: 3,
    image: require("./components/Images/wineImages/louis2.jpg")
  },
  {
    id: 4,
    image: require("./components/Images/wineImages/mythicus2.jpg")
  },
  {
    id: 5,
    image: require("./components/Images/wineImages/planeta2.jpg")
  },
  {
    id: 6,
    image: require("./components/Images/wineImages/ramey4.jpg")
  },
  {
    id: 7,
    image: require("./components/Images/wineImages/sokol3.jpg")
  },
  {
    id: 8,
    image: require("./components/Images/wineImages/weinbach2.jpg")
  },
  {
    id: 9,
    image: require("./components/Images/wineImages/petra-zingari-toscana2.jpg")
  },
  {
    id: 10,
    image: require("./components/Images/wineImages/farnese3.jpg")
  },
  {
    id: 11,
    image: require("./components/Images/wineImages/ceretto2.jpg")
  },
  {
    id: 12,
    image: require("./components/Images/wineImages/murrieta3.jpg")
  },
  {
    id: 13,
    image: require("./components/Images/wineImages/isabella3.jpg")
  },
  {
    id: 14,
    image: require("./components/Images/wineImages/mestis-blanco2.jpg")
  },
  {
    id: 15,
    image: require("./components/Images/wineImages/mestral2.jpg")
  }
];
