export default [
  {
    id: 0,
    image: require("./components/Images/Gallery/1.jpg")
  },
  {
    id: 1,
    image: require("./components/Images/Gallery/2.jpg")
  },
  {
    id: 2,
    image: require("./components/Images/Gallery/3.jpg")
  },
  {
    id: 3,
    image: require("./components/Images/Gallery/4.jpg")
  },
  {
    id: 4,
    image: require("./components/Images/Gallery/5.jpg")
  },
  {
    id: 5,
    image: require("./components//Images/Gallery/6.jpg")
  },
  {
    id: 6,
    image: require("./components/Images/Gallery/7.png")
  },
  {
    id: 7,
    image: require("./components/Images/Gallery/8.jpg")
  },
  {
    id: 8,
    image: require("./components/Images/Gallery/9.jpg")
  },
  {
    id: 9,
    image: require("./components/Images/Gallery/10.jpg")
  },
  {
    id: 10,
    image: require("./components/Images/Gallery/11.jpg")
  },
  {
    id: 11,
    image: require("./components/Images/Gallery/12.jpg")
  },
  {
    id: 12,
    image: require("./components/Images/Gallery/13.jpg")
  },
  {
    id: 13,
    image: require("./components/Images/Gallery/14.jpg")
  },
  {
    id: 14,
    image: require("./components/Images/Gallery/15.jpg")
  },
  {
    id: 15,
    image: require("./components/Images/Gallery/16.webp")
  },
  {
    id: 16,
    image: require("./components/Images/Gallery/17.jpg")
  },
  {
    id: 17,
    image: require("./components/Images/Gallery/18.jpg")
  },
  {
    id: 18,
    image: require("./components/Images/Gallery/19.jpg")
  },
  {
    id: 19,
    image: require("./components/Images/Gallery/20.jpg")
  },
  {
    id: 20,
    image: require("./components/Images/Gallery/21.jpg")
  },
  {
    id: 21,
    image: require("./components/Images/Gallery/22.jpg")
  },
  {
    id: 22,
    image: require("./components/Images/Gallery/23.jpg")
  },
  {
    id: 23,
    image: require("./components/Images/Gallery/24.jpg")
  },
  {
    id: 24,
    image: require("./components/Images/Gallery/25.png")
  },
  {
    id: 25,
    image: require("./components/Images/Gallery/26.jpg")
  },
  {
    id: 26,
    image: require("./components/Images/Gallery/27.jpg")
  },
  {
    id: 27,
    image: require("./components/Images/Gallery/28.jpg")
  },
  {
    id: 28,
    image: require("./components/Images/Gallery/29.jpg")
  },
  {
    id: 29,
    image: require("./components/Images/Gallery/30.jpg")
  },
  {
    id: 30,
    image: require("./components/Images/Gallery/31.jpg")
  },
  {
    id: 31,
    image: require("./components/Images/Gallery/32.jpg")
  },
  {
    id: 32,
    image: require("./components/Images/Gallery/33.jpg")
  },
  {
    id: 33,
    image: require("./components/Images/Gallery/34.jpg")
  },
  {
    id: 34,
    image: require("./components/Images/Gallery/35.jpg")
  },
  {
    id: 35,
    image: require("./components/Images/Gallery/36.jpg")
  }
];
